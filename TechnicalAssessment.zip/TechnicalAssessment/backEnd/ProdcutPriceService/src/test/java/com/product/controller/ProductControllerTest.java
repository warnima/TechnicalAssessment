package com.product.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.product.configuration.ServiceName;
import com.product.dto.CalculationRequest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ProductControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper mapper;

    private CalculationRequest calculationRequest;
    @Before
    public void init() {
        calculationRequest = new CalculationRequest();
        calculationRequest.setNoOfUnits(5);
        calculationRequest.setProductId(1);
    }

    @Test
    public void getAllProducts() throws Exception {
        mockMvc.perform(get("/"+ServiceName.BASE_URL+"/"+ServiceName.GET_ALL_PRODUCTS))
                .andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print());
    }

    @Test
    public void getAllProductsPriceTable() throws Exception {
        mockMvc.perform(get("/"+ServiceName.BASE_URL+"/"+ServiceName.GET_PRICE_TABLES))
                .andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print());
    }

    @Test
    public void caculateProductPrice() throws Exception {
        mockMvc.perform(post("/"+ServiceName.BASE_URL+"/"+ServiceName.CALCULATION)
                .content(mapper.writeValueAsString(calculationRequest))
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print());
    }


}
