package com.product.repository;

import com.product.domain.DiscountSlab;
import com.product.domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface DiscountSlabRepository extends JpaRepository<DiscountSlab,Long> {

    @Query("Select discountSlab.discount FROM DiscountSlab discountSlab WHERE discountSlab.product=:product AND :noOfUnits BETWEEN discountSlab.from AND discountSlab.to ")
    public double getDicoutForProduct(Product product,int noOfUnits);
}
