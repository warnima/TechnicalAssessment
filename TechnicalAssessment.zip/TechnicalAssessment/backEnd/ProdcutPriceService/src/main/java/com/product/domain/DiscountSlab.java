package com.product.domain;

import javax.persistence.*;

@Entity
@Table(name="discount_slab")
public class DiscountSlab {
    private long discountSlabId;
    private Product product;
    private int from;
    private int to;
    private double discount;

    @Id
    @Column(name="discount_slab_Id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long getDiscountSlabId() {
        return discountSlabId;
    }

    public void setDiscountSlabId(long discountSlabId) {
        this.discountSlabId = discountSlabId;
    }

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "product_Id")
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    @Column(name="item_from")
    public int getFrom() {
        return from;
    }

    public void setFrom(int from) {
        this.from = from;
    }

    @Column(name="item_to")
    public int getTo() {
        return to;
    }

    public void setTo(int to) {
        this.to = to;
    }

    @Column(name="discount")
    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }
}
