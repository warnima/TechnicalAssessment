package com.product.controller;

import com.product.Util;
import com.product.configuration.ServiceName;
import com.product.domain.Product;
import com.product.dto.CalculationRequest;
import com.product.dto.PriceShedule;
import com.product.dto.ProductPrice;
import com.product.dto.ProductPriceShedule;
import com.product.exception.InputValidationException;
import com.product.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
@RequestMapping(ServiceName.BASE_URL)
public class ProductController {
    @Autowired
    ProductService productService;

    @RequestMapping(ServiceName.GET_ALL_PRODUCTS)
    public @ResponseBody List<Product> getAllProducts(){
        return productService.getAllProducts();
    }

    @RequestMapping(ServiceName.CALCULATION)
    public ResponseEntity<ProductPrice> caculateProductPrice(@Valid @RequestBody CalculationRequest calculationRequest, BindingResult bindingResult) throws BindException {
        if (bindingResult.hasErrors()) {
            throw new InputValidationException(bindingResult);
        }
        double cost = productService.getProductPriceCalculaction(calculationRequest.getProductId(),calculationRequest.getNoOfUnits());
        Product product = productService.getProductById(calculationRequest.getProductId());
        ProductPrice productPrice = new ProductPrice();
        productPrice.setCost(Util.formatCurrency(cost));
        productPrice.setProductName(product.getDisplayName());
        productPrice.setNoOfUnits(calculationRequest.getNoOfUnits());
        productPrice.setCurrency(product.getCurrancy());
        return ResponseEntity.ok(productPrice);
    }

    @RequestMapping(ServiceName.GET_PRICE_TABLES)
    public ResponseEntity <List<ProductPriceShedule>> getAllProductsPriceTable(){
        Stream<Product> productStream = productService.getAllProducts().stream();
        List<ProductPriceShedule> returnList=productStream.map(s->{
            ProductPriceShedule productPriceShedule = new ProductPriceShedule();
            Stream<Integer> noOfUnits = Stream.iterate(1,n->n+1).limit(50);
            List<PriceShedule> sedule=noOfUnits.map(n->{
                PriceShedule priceShedule = new PriceShedule();
                double cost=productService.getProductPriceCalculaction(s.getProductId(),n.intValue());
                priceShedule.setNumberOfunit(n.intValue());
                priceShedule.setPrice(Util.formatCurrency(cost));
                priceShedule.setCurrancy(s.getCurrancy());
                return priceShedule;
            }).collect(Collectors.toList());
            productPriceShedule.setProductId(s.getProductId());
            productPriceShedule.setProductName(s.getDisplayName());
            productPriceShedule.setPriceShedules(sedule);
            return productPriceShedule;
        }).collect(Collectors.toList());
        return  ResponseEntity.ok(returnList);
    }

}
