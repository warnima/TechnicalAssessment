package com.product.configuration;

public class ServiceName {
    public static final String BASE_URL="api/product";
    public static final String CALCULATION="caculateProductPrice";
    public static final String GET_ALL_PRODUCTS="getAllProducts";
    public static final String GET_PRICE_TABLES="getAllProductsPriceTable";
}
