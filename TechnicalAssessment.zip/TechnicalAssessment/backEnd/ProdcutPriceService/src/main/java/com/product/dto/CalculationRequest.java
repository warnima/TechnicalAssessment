package com.product.dto;

import lombok.Data;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Data
public class CalculationRequest {

    @Min(value = 1,message = "Product cannot be empty")
    private long productId;
    @Min(value = 1 ,message = "Number of units must be grater then 0")
    private int noOfUnits;

    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public int getNoOfUnits() {
        return noOfUnits;
    }

    public void setNoOfUnits(int noOfUnits) {
        this.noOfUnits = noOfUnits;
    }
}
