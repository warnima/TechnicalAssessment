package com.product.domain;

import javax.persistence.*;

@Entity
@Table(name="additional_charges")
public class AdditionalCharges {
    private long additional_charge;
    private Product product;
    private double charge;

    @Id
    @Column(name="additional_charge_Id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long getAdditional_charge() {
        return additional_charge;
    }

    public void setAdditional_charge(long additional_charge) {
        this.additional_charge = additional_charge;
    }

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "product_Id")
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    @Column(name="charge")
    public double getCharge() {
        return charge;
    }

    public void setCharge(double charge) {
        this.charge = charge;
    }
}
