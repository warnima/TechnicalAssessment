package com.product.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.Map;
@ControllerAdvice
public class APIExceptionHandler {
    @ExceptionHandler(InputValidationException.class)
    public ResponseEntity<Map<String, String>> handleInputFieldException(InputValidationException exception) {
        return ResponseEntity.badRequest().body(exception.getErrorsMap());
    }

    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<Map<String, String>> handleDataAccessException(DataAccessException exception) {
        return ResponseEntity.badRequest().body(exception.getErrorMap());
    }
}
