package com.product.domain;

import javax.persistence.*;

@Entity
@Table(name="products")
public class Product {
    private long productId;
    private String productCode;
    private String productDescription;
    private String displayName;
    private String imageUrl;
    private int quantityOfCartoon;
    private double priceOfCartoon;
    private String currancy;

    @Id
    @Column(name="product_Id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    @Column(name="product_code")
    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    @Column(name="product_description")
    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    @Column(name="display_name")
    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    @Column(name="image_url")
    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @Column(name="qty_of_cartoon")
    public int getQuantityOfCartoon() {
        return quantityOfCartoon;
    }

    public void setQuantityOfCartoon(int quantityOfCartoon) {
        this.quantityOfCartoon = quantityOfCartoon;
    }

    @Column(name="price_of_cartoon")
    public double getPriceOfCartoon() {
        return priceOfCartoon;
    }

    public void setPriceOfCartoon(double priceOfCartoon) {
        this.priceOfCartoon = priceOfCartoon;
    }

    @Column(name="currancy")
    public String getCurrancy() {
        return currancy;
    }

    public void setCurrancy(String currancy) {
        this.currancy = currancy;
    }
}
