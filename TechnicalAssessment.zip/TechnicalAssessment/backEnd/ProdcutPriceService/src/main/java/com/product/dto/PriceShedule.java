package com.product.dto;

public class PriceShedule {
    private int numberOfunit;
    private String price;
    private String currancy;

    public int getNumberOfunit() {
        return numberOfunit;
    }

    public void setNumberOfunit(int numberOfunit) {
        this.numberOfunit = numberOfunit;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCurrancy() {
        return currancy;
    }

    public void setCurrancy(String currancy) {
        this.currancy = currancy;
    }
}
