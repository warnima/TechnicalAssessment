package com.product.repository;

import com.product.domain.AdditionalCharges;
import com.product.domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AdditionalChargeRepository extends JpaRepository<AdditionalCharges,Long> {
    @Query("Select addCharge.charge FROM AdditionalCharges addCharge WHERE addCharge.product=:product ")
    public double getAdditionalChargesBy(Product product);
}
