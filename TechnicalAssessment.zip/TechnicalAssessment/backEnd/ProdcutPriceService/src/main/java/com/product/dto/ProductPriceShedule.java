package com.product.dto;

import java.util.List;

public class ProductPriceShedule {
    private String productName;
    private long productId;
    private List<PriceShedule> priceShedules;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public List<PriceShedule> getPriceShedules() {
        return priceShedules;
    }

    public void setPriceShedules(List<PriceShedule> priceShedules) {
        this.priceShedules = priceShedules;
    }

    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }
}
