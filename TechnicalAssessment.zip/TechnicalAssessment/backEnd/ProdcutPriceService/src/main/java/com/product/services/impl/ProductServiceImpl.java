package com.product.services.impl;

import com.product.services.ProductService;
import com.product.domain.Product;
import com.product.exception.DataAccessException;
import com.product.repository.AdditionalChargeRepository;
import com.product.repository.DiscountSlabRepository;
import com.product.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private AdditionalChargeRepository additionalChargeRepository;
    @Autowired
    private DiscountSlabRepository discountSlabRepository;

    public ProductRepository getProductRepository() {
        return productRepository;
    }

    public void setProductRepository(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public AdditionalChargeRepository getAdditionalChargeRepository() {
        return additionalChargeRepository;
    }

    public void setAdditionalChargeRepository(AdditionalChargeRepository additionalChargeRepository) {
        this.additionalChargeRepository = additionalChargeRepository;
    }

    public DiscountSlabRepository getDiscountSlabRepository() {
        return discountSlabRepository;
    }

    public void setDiscountSlabRepository(DiscountSlabRepository discountSlabRepository) {
        this.discountSlabRepository = discountSlabRepository;
    }

    @Override
    public List<Product> getAllProducts() {
        return getProductRepository().findAll();
    }

    @Override
    public Product getProductById(long procuctId)  {
        Optional<Product> productOpt = productRepository.findById(procuctId);
        Product product;
        if(productOpt.isPresent())
            product = productOpt.get();
        else
            throw new DataAccessException("Product not Found");
        return product;
    }

    @Override
    public double getProductPriceCalculaction(long productId, int noOfUnits) {
        Product product = getProductById(productId);
        double noOfCartoon = Math.floor(noOfUnits/product.getQuantityOfCartoon());
        double singleUnits=noOfUnits%product.getQuantityOfCartoon();
        double priceForCartoon=0;
        double priceForSingleUnits=0;
        if(noOfCartoon>0) {
            double discountPrecentage = getDiscountSlabRepository().getDicoutForProduct(product, noOfUnits);
            priceForCartoon = (product.getPriceOfCartoon()*noOfCartoon)-(product.getPriceOfCartoon()*discountPrecentage);
        }
        if(singleUnits>0){
            double addChargePrecentage = getAdditionalChargeRepository().getAdditionalChargesBy(product);
            priceForSingleUnits = (addChargePrecentage*(product.getPriceOfCartoon()/product.getQuantityOfCartoon())+(product.getPriceOfCartoon()/product.getQuantityOfCartoon()))*singleUnits;
        }
        return (priceForCartoon+priceForSingleUnits);
    }


}
