package com.product.exception;

import java.util.HashMap;
import java.util.Map;

public class DataAccessException extends RuntimeException {
    private final Map<String,String> errorMap;
    public DataAccessException(String description){
        errorMap=new HashMap<>();
        errorMap.put("error",description);
    }

    public Map<String, String> getErrorMap() {
        return errorMap;
    }
}
