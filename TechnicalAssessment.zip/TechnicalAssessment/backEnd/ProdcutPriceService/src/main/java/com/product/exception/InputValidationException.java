package com.product.exception;

import lombok.Getter;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;
@Getter
public class InputValidationException extends RuntimeException {
    private final BindingResult bindingResult;
    private final Map<String, String> errorsMap;
    public InputValidationException(BindingResult bindingResult){
        this.bindingResult = bindingResult;
        this.errorsMap = bindingResult.getFieldErrors().stream().collect(collector);
    }

    Collector<FieldError, ?, Map<String, String>> collector = Collectors.toMap(
            fieldError -> fieldError.getField(),
            FieldError::getDefaultMessage
    );

    public BindingResult getBindingResult() {
        return bindingResult;
    }

    public Map<String, String> getErrorsMap() {
        return errorsMap;
    }
}
