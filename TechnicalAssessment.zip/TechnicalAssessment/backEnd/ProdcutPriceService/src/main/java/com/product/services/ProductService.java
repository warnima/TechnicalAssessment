package com.product.services;

import com.product.domain.Product;

import java.util.List;

public interface ProductService {
    public List<Product> getAllProducts();
    public Product getProductById(long procuctId);
    public double getProductPriceCalculaction(long procuctId, int noOfUnits);
}
