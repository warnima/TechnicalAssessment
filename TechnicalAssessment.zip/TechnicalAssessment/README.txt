Use Frame works
=====================
1.Spring boot for backend development.
2.React for frontend development.
3.MySQL for database.