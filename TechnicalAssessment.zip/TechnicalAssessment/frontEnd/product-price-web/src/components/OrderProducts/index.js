import React, { useState,Component,useEffect } from 'react';
import Select from 'react-select';
import { useHistory, useParams } from 'react-router';

import axios from '../../service/axios';
import { Container, Accordion, Card, Table, Button, Form, Col, Row } from 'react-bootstrap';



const OrderProducts = (props) => {
    let { id } = useParams();
    let [quantity, updateQuantity] = useState();
    let [results, updateResult] = useState();
    let [selectedOpt, updateSelectedOpt] = useState(id);
    let history = useHistory();
    let [productsOptions,updateProductsOptions]=useState();

    useEffect(() => {
        axios.get('/getAllProducts')
            .then(response => {
                if (response.status === 200) {
                    let opt = response.data.map(function (product) {
                        return { value: product.productId, label: product.displayName };
                    });
                    updateProductsOptions(opt);
                }
            })
            .catch(error => {
                console.log('getAllProductsPriceTable error === ', error)
            });
    }, []);

    const placeOrder = () => {
        axios.post('/caculateProductPrice', {
            "productId": selectedOpt,
            "noOfUnits": quantity
        }).then(response => {
            if (response.status === 200) {
                updateResult(response.data);
            }
        })
            .catch(error => {
            });
    }

    return (
        <div>
            <Container>
                <h1>
                    Calculate Quantity Price
                </h1>
                <Form>
                    <Form.Group as={Row} className="mb-3" controlId="formHorizontalProducts">
                        <Form.Label column sm={2}>
                            Product
                        </Form.Label>
                        <Col sm={5}>
                            {/*<Select options={productsOptions} selected={selectedOpt}  onChange={(e) => updateSelectedOpt(e.target.value)}  />*/}
                            <Form.Control as="select" value={selectedOpt} name="product" defaultValue={id}  onChange={(e) => updateSelectedOpt(e.target.value)} >
                                {productsOptions && productsOptions.map( product =>
                                    <option value={product.value}  >{product.label}</option>

                                )}
                            </Form.Control>
                        </Col>
                        <Col sm={5}>
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className="mb-3" controlId="formHorizontalQuantity">
                        <Form.Label column sm={2}>
                            Product Quantity
                        </Form.Label>
                        <Col sm={5}>
                            <Form.Control type="number"  min="1" placeholder="Please Input Quantity" onChange={(e) => updateQuantity(e.target.value)} />
                        </Col>
                        <Col sm={2}>
                            <Button onClick={() => placeOrder()}  >Calculate</Button>
                        </Col>
                    </Form.Group>
                </Form>
                {results &&
                <Table striped bordered hover>
                    <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>No Of Units</th>
                        <th>Cost</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>{results.productName}</td>
                        <td>{results.noOfUnits}</td>
                        <td>{results.cost}</td>
                    </tr>
                    </tbody>
                </Table>
                }
                <Button onClick={() => history.goBack()} >Back</Button>
            </Container>

        </div>
    );
}

export default OrderProducts;