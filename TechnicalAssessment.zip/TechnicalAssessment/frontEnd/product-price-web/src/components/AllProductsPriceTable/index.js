import React, { useState, useEffect } from 'react';
import axios from '../../service/axios';
import { Container, Accordion, Card, Table, Button } from 'react-bootstrap';
import { useHistory } from 'react-router';

const AllProductsPriceTable = (props) => {

    const [products, updateProducts] = useState(null);
    let history = useHistory();

    useEffect(() => {
        axios.get('/getAllProductsPriceTable')
            .then(response => {
                console.log('getAllProductsPriceTable === ', response)
                if (response.status === 200) {
                    updateProducts(response.data);
                }
            })
            .catch(error => {
                console.log('getAllProductsPriceTable error === ', error)
            });
    }, []);

    const placeOrder = (productId) => {
        history.push(`/orders/${productId}`)
    }

    return (
        <div>
            <Container>
                <h1>
                    Products Price Table
                </h1>
                <Table striped bordered hover>
                    <thead>
                    <tr>
                        <th>Product</th>
                        <th>Description</th>
                        <th>Order</th>
                    </tr>
                    </thead>
                    <tbody>
                    {products && products.map(product =>
                        <tr>
                            <td>{product.productName}</td>
                            <td>
                                <Table striped bordered hover>
                                    <thead>
                                    <tr>
                                        <th>Number Of Unit</th>
                                        <th>Price</th>
                                        <th>Currancy</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    {product.priceShedules.map(price =>
                                        <tr>
                                            <td>{price.numberOfunit}</td>
                                            <td>{price.price}</td>
                                            <td>{price.currancy}</td>
                                        </tr>
                                    )}
                                    </tbody>
                                </Table>
                            </td>
                            <td>
                                <Button onClick={() => placeOrder(product.productId)} >Calculate</Button>
                            </td>
                        </tr>
                    )}
                    </tbody>
                </Table>
            </Container>

        </div>
    );
}

export default AllProductsPriceTable;