import React, { Component } from 'react';
import { Route, Switch } from 'react-router-dom';

import AllProductsPriceTable from './components/AllProductsPriceTable';
import OrderProducts from './components/OrderProducts';

class App extends Component{
  render() {
    return (
        <div>
          <Switch>
            <Route path="/orders/:id" component={OrderProducts} />
            <Route path="/" exact component={AllProductsPriceTable} />
          </Switch>
        </div>
    );
  }
}

export default App;
