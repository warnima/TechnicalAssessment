1.need install node.js
2.go to product-price-web folder
3.run 'npm install'